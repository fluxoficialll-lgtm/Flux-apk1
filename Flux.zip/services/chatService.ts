
import { db } from '@/database';
import { ChatMessage, ChatData } from '../types';
import { recommendationService } from './recommendationService';
import { authService } from './authService';
import { API_BASE } from '../apiConfig';
import { socketService } from './socketService';

// Re-export for consumers (pages)
export type { ChatMessage, ChatData };

const API_URL = `${API_BASE}/api/chats`;

export const chatService = {
    getAllChats: (): Record<string, ChatData> => {
        const chats = db.chats.getAll();
        return chats;
    },

    // NEW: Sync all chats for the user from server (Recovery/Login)
    syncChats: async () => {
        const userEmail = authService.getCurrentUserEmail();
        if (!userEmail) return;

        try {
            const response = await fetch(`${API_URL}/sync?email=${encodeURIComponent(userEmail)}`);
            if (response.ok) {
                const data = await response.json();
                if (data.chats && Array.isArray(data.chats)) {
                    data.chats.forEach((chat: ChatData) => {
                        // Merge or overwrite local
                        db.chats.set(chat);
                    });
                    console.log(`✅ [ChatSync] Restored ${data.chats.length} chats.`);
                }
            }
        } catch (e) {
            console.warn("Chat sync failed (offline?)", e);
        }
    },

    // Helper to generate a consistent ID for private chats between two users
    getPrivateChatId: (email1: string, email2: string): string => {
        const sorted = [email1, email2].sort();
        return `${sorted[0]}_${sorted[1]}`;
    },

    getChat: (id: string): ChatData => {
        // Try to load history from server if local is empty/sparse
        let chat = db.chats.get(id);
        if (!chat) {
            // Create new empty chat if not exists (lazy creation)
            chat = {
                id,
                contactName: 'Chat', // Placeholder
                isBlocked: false,
                messages: []
            };
            db.chats.set(chat);
            
            // Trigger initial fetch from server (limit 50)
            chatService.fetchChatMessages(id, 50).catch(console.error);
        }
        return chat;
    },

    // NEW: Paginated Message Fetching
    fetchChatMessages: async (chatId: string, limit: number = 50, beforeId?: number) => {
        try {
            let url = `${API_URL}/${chatId}?limit=${limit}`;
            if (beforeId) url += `&before=${beforeId}`;

            const response = await fetch(url);
            if (response.ok) {
                const data = await response.json();
                const newMessages = data.data || [];
                
                if (newMessages.length > 0) {
                    const chat = db.chats.get(chatId) || { id: chatId, contactName: 'Chat', isBlocked: false, messages: [] };
                    
                    // Merge logic: avoid duplicates based on ID
                    const existingIds = new Set(chat.messages.map(m => m.id));
                    const uniqueNew = newMessages.filter((m: ChatMessage) => !existingIds.has(m.id));
                    
                    if (uniqueNew.length > 0) {
                        // Merge and sort ascending by ID (oldest -> newest) for display
                        const allMessages = [...chat.messages, ...uniqueNew].sort((a, b) => a.id - b.id);
                        chat.messages = allMessages;
                        db.chats.set(chat);
                    }
                    return uniqueNew.length; // Return count of newly added messages
                }
            }
        } catch (e) {
            console.error("Failed to fetch chat messages:", e);
        }
        return 0; // No new messages
    },

    // Legacy method redirection
    fetchChatHistory: async (chatId: string) => {
        return chatService.fetchChatMessages(chatId);
    },

    getUnreadCount: (): number => {
        const allChats = chatService.getAllChats();
        let count = 0;
        const currentUserEmail = authService.getCurrentUserEmail();
        
        if (!currentUserEmail) return 0;

        Object.values(allChats).forEach(chat => {
            const chatIdStr = chat.id.toString();
            // Ignore Group Chats for main badge
            if (!chatIdStr.includes('@')) return;
            if (!chatIdStr.includes(currentUserEmail)) return;

            const unreadInChat = chat.messages.filter(m => {
                if (m.senderEmail) {
                    return m.senderEmail !== currentUserEmail && m.status !== 'read';
                }
                return m.type === 'received' && m.status !== 'read';
            }).length;
            
            count += unreadInChat;
        });
        return count;
    },

    getGroupUnreadCount: (groupId?: string): number => {
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!currentUserEmail) return 0;
        
        const countFn = (chat: ChatData) => chat.messages.filter(m => {
             const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
             return isFromOther && m.status !== 'read';
        }).length;

        if (groupId) {
            const chat = db.chats.get(groupId);
            return chat ? countFn(chat) : 0;
        }

        const allChats = db.chats.getAll();
        let total = 0;
        Object.values(allChats).forEach(chat => {
            if (!chat.id.toString().includes('@')) { 
                total += countFn(chat);
            }
        });
        return total;
    },

    getUnreadCountForChat: (chatId: string): number => {
        const chat = db.chats.get(chatId);
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!chat || !currentUserEmail) return 0;
        
        return chat.messages.filter(m => {
            if (m.senderEmail) {
                return m.senderEmail !== currentUserEmail && m.status !== 'read';
            }
            return m.type === 'received' && m.status !== 'read';
        }).length;
    },

    markChatAsRead: (chatId: string) => {
        const chat = db.chats.get(chatId);
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!chat || !currentUserEmail) return;

        let changed = false;
        const newMessages = chat.messages.map(m => {
            const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
            if (isFromOther && m.status !== 'read') {
                changed = true;
                return { ...m, status: 'read' as const };
            }
            return m;
        });

        if (changed) {
            const updatedChat = { ...chat, messages: newMessages };
            db.chats.set(updatedChat);
        }
    },

    markAllAsRead: () => {
        const allChats = chatService.getAllChats();
        const currentUserEmail = authService.getCurrentUserEmail();
        if (!currentUserEmail) return;

        Object.values(allChats).forEach(chat => {
            const chatIdStr = chat.id.toString();
            if (!chatIdStr.includes('@')) return;
            if (!chatIdStr.includes(currentUserEmail)) return;

            let changed = false;
            const newMessages = chat.messages.map(m => {
                const isFromOther = m.senderEmail ? m.senderEmail !== currentUserEmail : m.type === 'received';
                if (isFromOther && m.status !== 'read') {
                    changed = true;
                    return { ...m, status: 'read' as const };
                }
                return m;
            });

            if (changed) {
                const updatedChat = { ...chat, messages: newMessages };
                db.chats.set(updatedChat);
            }
        });
    },

    sendMessage: async (chatId: string, message: ChatMessage) => {
        // 1. Optimistic Update (Visual Instantâneo)
        const chat = db.chats.get(chatId);
        let chatData = chat;

        if (!chatData) {
             chatData = {
                id: chatId,
                contactName: 'Chat',
                isBlocked: false,
                messages: []
            };
        }
        
        chatData.messages.push(message);
        db.chats.set(chatData);

        // 2. Send to Backend API
        try {
            await fetch(`${API_URL}/send`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chatId, message })
            });
        } catch (e) {
            console.error("Erro ao enviar mensagem para o servidor:", e);
        }

        // --- ALGORITHM INTEGRATION ---
        if (message.type === 'sent' && message.contentType === 'text') {
            const email = authService.getCurrentUserEmail();
            if (email) {
                setTimeout(() => {
                    recommendationService.analyzeMessage(email, message.text);
                }, 100);
            }
        }
    },

    clearChat: (chatId: string) => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.messages = [];
            db.chats.set(chat);
        }
    },

    // REFACTORED FOR PERSISTENCE AND REAL-TIME
    deleteMessages: async (chatId: string, messageIds: number[], mode: 'me' | 'all' = 'me') => {
        const userEmail = authService.getCurrentUserEmail();
        if (!userEmail) return;

        // 1. Optimistic Update
        const chat = db.chats.get(chatId);
        if (chat) {
            if (mode === 'all') {
                // For "all", we redact it instead of removing to maintain consistency with backend
                // Only for own messages or admin
                chat.messages = chat.messages.map(m => {
                    if (messageIds.includes(m.id)) {
                        return { 
                            ...m, 
                            text: '🚫 Esta mensagem foi apagada.', 
                            contentType: 'text',
                            mediaUrl: undefined,
                            product: undefined,
                            // Adding flag for UI styling if needed
                            isDeleted: true // You might need to add this to ChatMessage type if strict
                        };
                    }
                    return m;
                });
            } else {
                // For "me", we just hide/remove it locally
                chat.messages = chat.messages.filter(m => !messageIds.includes(m.id));
            }
            db.chats.set(chat);
        }

        // 2. Call API
        try {
            await fetch(`${API_URL}/delete-messages`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chatId, messageIds, mode, userEmail })
            });
        } catch (e) {
            console.error("Failed to delete messages on server:", e);
        }
    },

    toggleBlock: (chatId: string): boolean => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
            return chat.isBlocked;
        }
        return false;
    },

    toggleBlockByContactName: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        let chat = Object.values(chats).find(c => c.contactName === contactName);
        
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
        } else {
            const newId = Date.now().toString();
            chat = {
                id: newId,
                contactName: contactName,
                isBlocked: true,
                messages: []
            };
            db.chats.set(chat);
        }
        
        return chat.isBlocked;
    },
    
    isUserBlocked: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        const chat = Object.values(chats).find(c => c.contactName === contactName);
        return chat ? chat.isBlocked : false;
    },

    hasBlockingRelationship: (currentUserEmail: string, targetIdentifier: string): boolean => {
        if (!currentUserEmail || !targetIdentifier) return false;
        let cleanTarget = targetIdentifier;
        if (cleanTarget.startsWith('@')) cleanTarget = cleanTarget.substring(1);

        let targetEmail = cleanTarget;
        if (!cleanTarget.includes('@') || !cleanTarget.includes('.')) {
             const user = authService.getUserByHandle(cleanTarget);
             if (user) targetEmail = user.email;
        }

        const chatId = chatService.getPrivateChatId(currentUserEmail, targetEmail);
        const chat = db.chats.get(chatId);
        if (chat && chat.isBlocked) return true;

        const allChats = db.chats.getAll();
        return Object.values(allChats).some(c => 
            c.isBlocked && 
            (c.contactName === cleanTarget || c.contactName === `@${cleanTarget}` || c.id === chatId)
        );
    },

    getBlockedIdentifiers: (currentUserEmail: string): Set<string> => {
        const blockedSet = new Set<string>();
        const allChats = db.chats.getAll();
        const allUsers = db.users.getAll();

        Object.values(allChats).forEach(chat => {
            if (chat.isBlocked) {
                const chatId = chat.id.toString();
                if (chatId.includes(currentUserEmail) && chatId.includes('_')) {
                    const parts = chatId.split('_');
                    const otherEmail = parts.find(p => p !== currentUserEmail);
                    if (otherEmail) {
                        blockedSet.add(otherEmail);
                        const user = allUsers[otherEmail];
                        if (user?.profile?.name) {
                            blockedSet.add(user.profile.name);
                            blockedSet.add(`@${user.profile.name}`);
                        }
                    }
                } 
                else if (chat.contactName) {
                    blockedSet.add(chat.contactName);
                    blockedSet.add(`@${chat.contactName}`);
                    const user = authService.getUserByHandle(chat.contactName);
                    if (user) blockedSet.add(user.email);
                }
            }
        });
        return blockedSet;
    },

    // --- SOCKET.IO LISTENER SETUP ---
    initSocketListeners: () => {
        const currentUserEmail = authService.getCurrentUserEmail();
        
        socketService.on('new_private_message', (data: { chatId: string, message: ChatMessage }) => {
            const { chatId, message } = data;
            
            if (message.senderEmail !== currentUserEmail) {
                const incomingMsg = { ...message, type: 'received' as const };
                
                const chat = db.chats.get(chatId);
                if (chat) {
                    if (!chat.messages.some(m => m.id === message.id)) {
                        chat.messages.push(incomingMsg);
                        db.chats.set(chat);
                    }
                } else {
                    const newChat = {
                        id: chatId,
                        contactName: message.senderName || message.senderEmail || 'Desconhecido',
                        isBlocked: false,
                        messages: [incomingMsg]
                    };
                    db.chats.set(newChat);
                }
            }
        });

        socketService.on('new_message', (data: { chatId: string, message: ChatMessage }) => {
            const { chatId, message } = data;
            if (message.senderEmail === currentUserEmail) return;

            const chat = db.chats.get(chatId);
            if (chat) {
                if (!chat.messages.some(m => m.id === message.id)) {
                    chat.messages.push({ ...message, type: 'received' });
                    db.chats.set(chat);
                }
            }
        });

        // REAL-TIME DELETION LISTENER
        socketService.on('messages_deleted', (data: { chatId: string, messageIds: number[], mode: string, deleterEmail: string }) => {
            const { chatId, messageIds, mode, deleterEmail } = data;
            
            if (deleterEmail === currentUserEmail) return; // Already handled optimistically

            const chat = db.chats.get(chatId);
            if (chat) {
                if (mode === 'all') {
                    // Redact content for 'everyone' delete
                    chat.messages = chat.messages.map(m => {
                        if (messageIds.includes(m.id)) {
                            return { 
                                ...m, 
                                text: '🚫 Esta mensagem foi apagada.',
                                contentType: 'text',
                                mediaUrl: undefined,
                                product: undefined,
                                // @ts-ignore
                                isDeleted: true 
                            };
                        }
                        return m;
                    });
                }
                // For 'me', we don't do anything because that only affects the deleter's view
                
                db.chats.set(chat);
            }
        });
    }
};

chatService.initSocketListeners();
