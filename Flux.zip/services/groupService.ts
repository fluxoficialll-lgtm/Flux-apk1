
import { Group, User, GroupLink } from '../types';
import { db } from '@/database';
import { authService } from './authService';
import { API_BASE } from '../apiConfig';

const API_URL = `${API_BASE}/api/groups`;

export const groupService = {
    fetchGroups: async (): Promise<Group[]> => {
        const userEmail = authService.getCurrentUserEmail();
        let url = API_URL;
        
        if (userEmail) {
            url += `?email=${encodeURIComponent(userEmail)}`;
        }

        try {
            const response = await fetch(url);
            if (response.ok) {
                const data = await response.json();
                if (data.data) {
                    db.groups.saveAll(data.data);
                }
            }
        } catch (e) {
            console.warn("Falha ao buscar grupos no servidor, usando cache local.");
        }
        
        return db.groups.getAll();
    },

    getGroupsSync: (): Group[] => {
        return db.groups.getAll();
    },

    // NEW: Get groups with pagination from local DB
    getGroupsPaginated: (offset: number, limit: number): { groups: Group[], hasMore: boolean } => {
        const allGroups = db.groups.getAll();
        const userEmail = authService.getCurrentUserEmail();
        
        // Filter groups relevant to the user (my groups + public)
        // Note: For the main list, we usually filter by membership in the UI, 
        // but here we return raw data and let UI filter or filter here if needed.
        // Assuming Groups.tsx filters by membership:
        
        const myGroups = userEmail 
            ? allGroups.filter(g => g.members?.includes(userEmail)) 
            : [];

        // Sort: Newest first (assuming ID is timestamp based or use time field)
        const sorted = myGroups.sort((a, b) => Number(b.id) - Number(a.id));
        
        const slice = sorted.slice(offset, offset + limit);
        return {
            groups: slice,
            hasMore: offset + limit < sorted.length
        };
    },

    getAllGroupsForRanking: async (): Promise<Group[]> => {
        try {
            const response = await fetch(`${API_URL}/ranking`);
            if (response.ok) {
                const data = await response.json();
                if (data.data) {
                    // Update local cache with ranking data
                    db.groups.saveAll(data.data);
                    return data.data;
                }
            }
        } catch (e) {
            console.warn("Failed to fetch ranking", e);
        }
        return db.groups.getAll();
    },

    getGroupById: (id: string): Group | undefined => {
        return db.groups.findById(id);
    },

    // NEW: Async fetch that hits server if not local (For Sales Page)
    fetchGroupById: async (id: string): Promise<Group | null> => {
        // 1. Local Cache (Fastest)
        const local = db.groups.findById(id);
        if (local) return local;

        // 2. Network Fetch (Public Endpoint)
        try {
            const response = await fetch(`${API_URL}/${id}`);
            if (response.ok) {
                const data = await response.json();
                if (data.group) {
                    // Cache it for future use
                    db.groups.add(data.group);
                    return data.group;
                }
            }
        } catch (e) {
            console.error("Fetch group by ID error:", e);
        }
        return null;
    },

    createGroup: async (group: Group) => {
        try {
            const response = await fetch(`${API_URL}/create`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(group)
            });
            
            if (response.ok) {
                db.groups.add(group);
            } else {
                throw new Error("Erro no servidor");
            }
        } catch (e) {
            console.error("Failed to create group:", e);
            // Optimistic UI for offline creation (optional, but risky without server ID)
            // db.groups.add(group); 
            throw e;
        }
    },

    updateGroup: async (group: Group) => {
        db.groups.update(group); // Optimistic
        try {
            await fetch(`${API_URL}/${group.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(group)
            });
        } catch (e) {
            console.error("Failed to update group on server:", e);
        }
    },

    deleteGroup: async (id: string) => {
        db.groups.delete(id); // Optimistic
        try {
            await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });
        } catch (e) {
            console.error("Failed to delete group on server:", e);
        }
    },

    joinGroup: (groupId: string): 'joined' | 'pending' | 'full' | 'banned' | 'error' => {
        const userEmail = authService.getCurrentUserEmail();
        if (!userEmail) return 'error';

        const group = db.groups.findById(groupId);
        if (!group) return 'error';

        if (group.bannedUsers?.includes(userEmail)) return 'banned';
        if (group.settings?.memberLimit && (group.members?.length || 0) >= group.settings.memberLimit) return 'full';

        // Check if already member
        if (group.members?.includes(userEmail)) return 'joined';

        // Private logic
        if (group.isPrivate && !group.pendingMembers?.includes(userEmail)) {
            const updatedGroup = {
                ...group,
                pendingMembers: [...(group.pendingMembers || []), userEmail]
            };
            groupService.updateGroup(updatedGroup);
            return 'pending';
        }

        // Public/VIP logic (VIP usually handled via Payment flow, but if free/owner logic allows)
        if (!group.members?.includes(userEmail)) {
            const updatedGroup = {
                ...group,
                members: [...(group.members || []), userEmail]
            };
            groupService.updateGroup(updatedGroup);
            return 'joined';
        }

        return 'error';
    },

    leaveGroup: async (groupId: string) => {
        const userEmail = authService.getCurrentUserEmail();
        if (!userEmail) return;

        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            members: group.members?.filter(m => m !== userEmail) || [],
            admins: group.admins?.filter(a => a !== userEmail) || []
        };
        
        await groupService.updateGroup(updatedGroup);
    },

    checkVipStatus: (groupId: string, userEmail: string): 'active' | 'expired' | 'grace_period' | 'none' => {
        const access = db.vipAccess.get(userEmail, groupId);
        
        if (!access) return 'none';
        
        if (access.status === 'active') {
            if (access.expiresAt) {
                const now = Date.now();
                // Grace period: 24h (86400000 ms) after expiration
                if (now > access.expiresAt + 86400000) return 'expired';
                if (now > access.expiresAt) return 'grace_period';
            }
            return 'active';
        }
        
        return 'expired';
    },

    getGroupMembers: (groupId: string): User[] => {
        const group = db.groups.findById(groupId);
        if (!group || !group.members) return [];
        
        const allUsers = db.users.getAll();
        return group.members.map(email => allUsers[email] || { 
            email, 
            isVerified: false, 
            isProfileCompleted: false, 
            profile: { name: email.split('@')[0], isPrivate: false } 
        } as User);
    },

    getPendingMembers: (groupId: string): User[] => {
        const group = db.groups.findById(groupId);
        if (!group || !group.pendingMembers) return [];
        
        const allUsers = db.users.getAll();
        return group.pendingMembers.map(email => allUsers[email] || { 
            email, 
            isVerified: false, 
            isProfileCompleted: false, 
            profile: { name: email.split('@')[0], isPrivate: false } 
        } as User);
    },

    approveMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            pendingMembers: group.pendingMembers?.filter(m => m !== userEmail) || [],
            members: [...(group.members || []), userEmail]
        };
        groupService.updateGroup(updatedGroup);
    },

    rejectMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            pendingMembers: group.pendingMembers?.filter(m => m !== userEmail) || []
        };
        groupService.updateGroup(updatedGroup);
    },

    removeMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            members: group.members?.filter(m => m !== userEmail) || [],
            admins: group.admins?.filter(a => a !== userEmail) || []
        };
        groupService.updateGroup(updatedGroup);
    },

    banMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            members: group.members?.filter(m => m !== userEmail) || [],
            admins: group.admins?.filter(a => a !== userEmail) || [],
            bannedUsers: [...(group.bannedUsers || []), userEmail]
        };
        groupService.updateGroup(updatedGroup);
    },

    promoteMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            admins: [...(group.admins || []), userEmail]
        };
        groupService.updateGroup(updatedGroup);
    },

    demoteMember: (groupId: string, userEmail: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            admins: group.admins?.filter(a => a !== userEmail) || []
        };
        groupService.updateGroup(updatedGroup);
    },

    addGroupLink: (groupId: string, name: string, maxUses?: number, expiresAt?: string): GroupLink | null => {
        const group = db.groups.findById(groupId);
        if (!group) return null;

        const newLink: GroupLink = {
            id: Date.now().toString(),
            name,
            code: Math.random().toString(36).substring(2, 8).toUpperCase(),
            joins: 0,
            createdAt: Date.now(),
            maxUses,
            expiresAt
        };

        const updatedGroup = {
            ...group,
            links: [newLink, ...(group.links || [])]
        };
        groupService.updateGroup(updatedGroup);
        return newLink;
    },

    removeGroupLink: (groupId: string, linkId: string) => {
        const group = db.groups.findById(groupId);
        if (!group) return;

        const updatedGroup = {
            ...group,
            links: group.links?.filter(l => l.id !== linkId) || []
        };
        groupService.updateGroup(updatedGroup);
    },

    joinGroupByLinkCode: (code: string): { success: boolean; message: string; groupId?: string } => {
        const allGroups = db.groups.getAll();
        
        for (const group of allGroups) {
            if (group.links) {
                const link = group.links.find(l => l.code === code);
                if (link) {
                    // Check Limits
                    if (link.maxUses && link.joins >= link.maxUses) {
                        return { success: false, message: 'Este link de convite expirou (limite de usos).' };
                    }
                    if (link.expiresAt && new Date(link.expiresAt).getTime() < Date.now()) {
                        return { success: false, message: 'Este link de convite expirou (data).' };
                    }

                    // Increment joins (Ideally this happens on server, simulating locally)
                    link.joins++;
                    groupService.updateGroup(group);

                    // Try to join
                    const joinResult = groupService.joinGroup(group.id);
                    
                    if (joinResult === 'joined') return { success: true, message: 'Você entrou no grupo!', groupId: group.id };
                    if (joinResult === 'pending') return { success: true, message: 'Solicitação enviada!', groupId: undefined };
                    if (joinResult === 'full') return { success: false, message: 'Grupo lotado.' };
                    if (joinResult === 'banned') return { success: false, message: 'Você está banido deste grupo.' };
                    // Default to success if already member
                    return { success: true, message: 'Você já é membro.', groupId: group.id };
                }
            }
        }
        return { success: false, message: 'Código de convite inválido.' };
    }
};
